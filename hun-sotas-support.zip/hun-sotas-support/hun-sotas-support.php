<?php
/**
 * Plugin Name: Hun Sotas Support
 * Plugin URI: https://github.com/HunThemes/hun-sotas-support
 * Description: Hun Sotas Support Plugin supports creating new custom post type, widget for SotaS Theme
 * Version: 1.0
 * Author: HunThemes
 * Author URI: https://themeforest.net/user/hunthemes/portfolio
 */

function hls_load_textdomain() {
  load_plugin_textdomain( 'hun-sotas-support', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'hls_load_textdomain' );

/**
 * Post Widget
 */
class Hun_Post_Widget extends WP_Widget {

	private $defaults = array(
		'title'           => '',
		'number_of_items' => '3',
		'show'            => 'recent',
	);

	function __construct() {
		parent::__construct(
			'hun_sotas_post',
			esc_html__( 'Sotas Post Widget', 'hun-sotas-support' ),
			array( 'description' => esc_html__( 'Displays a list of Recent Posts or Related Posts)', 'hun-sotas-support' ), )
		);
	}

	public function form( $instance ) {
		$instance = wp_parse_args((array) $instance,$this->defaults );

		$title = esc_attr( $instance['title'] );
		$number_of_items = esc_attr( $instance['number_of_items'] ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:', 'hun-sotas-support' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>"/>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'number_of_items' ); ?>"><?php esc_html_e( 'Number of items to show:', 'hun-sotas-support' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'number_of_items' ); ?>" name="<?php echo $this->get_field_name( 'number_of_items' ); ?>" type="number" value="<?php echo $number_of_items; ?>"/>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'show' ); ?>"><?php esc_html_e( 'Show:', 'hun-sotas-support' ); ?></label>
			<select name="<?php echo $this->get_field_name( 'show' ); ?>" id="<?php echo $this->get_field_id( 'show' ); ?>" class="widefat">
				<option value="recent"<?php selected( $instance['show'], 'recent' ); ?>><?php esc_html_e( 'Recent Posts', 'hun-sotas-support' ); ?></option>
				<option value="related-by-category"<?php selected( $instance['show'], 'related-by-category' ); ?>><?php esc_html_e( 'Related Posts By Category', 'hun-sotas-support' ); ?></option>
				<option value="related-by-tag"<?php selected( $instance['show'], 'related-by-tag' ); ?>><?php esc_html_e( 'Related Posts By Tag', 'hun-sotas-support' ); ?></option>
			</select>
		</p>

		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance                    = $old_instance;
		$instance['title']           = strip_tags( $new_instance['title'] );
		$instance['number_of_items'] = strip_tags( $new_instance['number_of_items'] );

		if ( intval( $instance['number_of_items'] ) < 1 ) {
			$instance['number_of_items'] = '1';
		}

		if ( in_array( $new_instance['show'], array( 'recent', 'related-by-category', 'related-by-tag' ) ) ) {
			$instance['show'] = $new_instance['show'];
		} else {
			$instance['show'] = 'recent';
		}

		return $instance;
	}

	public function widget( $args, $instance ) {
		global $post;

		$title           = apply_filters( 'widget_title', empty( $instance['title'] ) ? $this->defaults['title'] : $instance['title']);
		$number_of_items = empty( $instance['number_of_items'] ) ? $this->defaults['number_of_items'] : $instance['number_of_items'];
		$show            = empty( $instance['show'] ) ? $this->defaults['show'] : $instance['show'];

		echo $args['before_widget'];

		echo $args['before_title'].$title.$args['after_title']; ?>

		<div class="list-post">
			<?php 
				$query_args = array(
					'post_type' => 'post',
					'posts_per_page' => $number_of_items,
					'post_status' => 'publish',
					'orderby' => 'date',
					'ignore_sticky_posts' => true,
				);

				if ( ! empty( $show ) && $show === 'related-by-category' ) {
					$query_args['category__in'] = wp_get_post_categories($post->ID);
					$query_args['post__not_in'] = array($post->ID);
				}
				else if (! empty( $show ) && $show === 'related-by-tag') {
					$tags = wp_get_post_tags( $post->ID );
					$arr_id_tags = array();

					for ($i = 0; $i < count($tags); $i++) {
						array_push($arr_id_tags, $tags[$i]->term_id);
					}

					$query_args['tag__in'] = $arr_id_tags;
					$query_args['post__not_in'] = array( $post->ID );
				}
				
				$the_query = new WP_Query( $query_args ); 
			?>

			<?php if ( $the_query->have_posts() ) : ?>
				<?php while( $the_query->have_posts() ) : $the_query->the_post(); ?>

					<div <?php post_class('item-post'); ?>>
						<a class="pic-post" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" style="background-image: url(<?php the_post_thumbnail_url('thumbnail'); ?>);"></a>

						<div class="text-post">
							<h4 class="title-post" title="<?php the_title(); ?>">
								<a href="<?php the_permalink(); ?>">
									<?php the_title(); ?>
								</a>
							</h4>

							<div class="date-post">
								<?php echo get_the_date(); ?>
							</div>
						</div>
					</div>
				 
				<?php endwhile; ?>

				<?php wp_reset_postdata(); ?>

			<?php else : ?>
  				<p><?php __( 'No Posts', 'hun-sotas-support' ); ?></p>
			<?php endif; ?>
		</div>
		<?php echo $args['after_widget'];
	}
}


/**
 * class Hun_Sotas_Support
 */
if(!class_exists('Hun_Sotas_Support')) {
	class Hun_Sotas_Support {
		function __construct() {

			/**
			 * Create Case Study Post Type
			 */
			function create_case_study_post_type() {
			    $label = array(
			        'name' 					=> _x('Case Studies', 'Post Type General Name' , 'hun-sotas-support'),
			        'singular_name' 		=> _x('Case Study', 'Post Type Singular Name' , 'hun-sotas-support'),
			        'menu_name'             => _x('Case Studies', 'Post Type Menu Name' , 'hun-sotas-support'),
					'name_admin_bar'        => _x('Case Study', 'Post Type Name Admin Bar' , 'hun-sotas-support'),
			        'all_items' 			=> __('All Case Studies', 'hun-sotas-support'),
			        'add_new' 				=> __('Add New', 'hun-sotas-support'),
			        'add_new_item' 			=> __('Add New Case Study', 'hun-sotas-support'),
					'edit_item' 			=> __('Edit Case Study', 'hun-sotas-support'),
					'new_item' 				=> __('New Case Study', 'hun-sotas-support'),
					'view_item' 			=> __('View Case Study', 'hun-sotas-support'),
					'view_items' 			=> __('View Case Studies', 'hun-sotas-support'),
					'search_items' 			=> __('Search Case Studies', 'hun-sotas-support'),
					'not_found' 			=> __('No case studies found', 'hun-sotas-support'),
					'not_found_in_trash' 	=> __('No case studies found in Trash', 'hun-sotas-support'),
					'archives' 				=> __('Case Study Archives', 'hun-sotas-support'),
					'attributes' 			=> __('Case Study Attributes', 'hun-sotas-support'),
					'insert_into_item' 		=> __('Insert into case study', 'hun-sotas-support'),
					'uploaded_to_this_item' => __('Uploaded to this case study', 'hun-sotas-support'),
			    );
			 
			    $args = array(
			        'description' 			=> __('Case Study Post Type', 'hun-sotas-support' ),
			        'labels' 				=> $label,
			        'show_in_rest' 			=> true,
			        'supports' 				=> array(
									            'title',
									            'editor',
									            'excerpt',
									            'thumbnail',
									            'revisions', 
									        ),
			        'hierarchical' 			=> false, 
			        'public' 				=> true, 
			        'show_ui' 				=> true, 
			        'show_in_menu' 			=> true, 
			        'show_in_nav_menus' 	=> true,
			        'show_in_admin_bar' 	=> true, 
			        'menu_position' 		=> 5,
			        'can_export' 			=> true, 
			        'has_archive' 			=> false, 
			        'exclude_from_search' 	=> false, 
			        'publicly_queryable' 	=> true, 
			        'rewrite' 				=> array('slug' => _x('case-study', 'Post Type Slug' , 'hun-sotas-support' )),
			        'capability_type' 		=> 'post',
			    );
			 
			    register_post_type('hun_sotas_case_study', $args);
			    flush_rewrite_rules();
			}
			add_action('init', 'create_case_study_post_type');

			function case_study_meta_box( $meta_boxes ) {
				$prefix = 'hun-';

				$meta_boxes[] = array(
					'id' => 'hun_metabox_case_study',
					'title' => esc_html__( 'Meta Info', 'hun-sotas-support' ),
					'post_types' => array('hun_sotas_case_study' ),
					'context' => 'normal',
					'priority' => 'high',
					'autosave' => 'false',
					'fields' => array(
						array(
							'id' => $prefix . 'sotas_brand',
							'type' => 'image_advanced',
							'name' => esc_html__( 'Brand', 'hun-sotas-support' ),
							'max_file_uploads' => '1',
						),
						array(
							'id' => $prefix . 'divider_1',
							'type' => 'divider',
							'name' => esc_html__( 'Divider', 'hun-sotas-support' ),
						),
						array(
							'id'      => $prefix . 'sotas_info',
							'type'    => 'fieldset_text',
							'name'    => esc_html__( 'Info List', 'hun-sotas-support' ),
							'options' => array(
								'info'    => esc_html__( 'Info', 'hun-sotas-support' ),
								'value' => esc_html__( 'Value', 'hun-sotas-support' ),
							),
							'clone' => true,
						),
					),
				);

				return $meta_boxes;
			}
			add_filter( 'rwmb_meta_boxes', 'case_study_meta_box' );


			/**
			 * Widgets.
			 */
			function hun_register_widgets() {
				register_widget( 'Hun_Post_Widget' );
			}
			add_action( 'widgets_init', 'hun_register_widgets' );
		}
	}
}
function hls_load() {
        global $hls;
        $hls = new Hun_Sotas_Support();
}
add_action( 'plugins_loaded', 'hls_load' );


